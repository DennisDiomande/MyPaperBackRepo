# Netsky's Repo Index
[Github Repo](https://github.com/TheNetsky/netskys-extensions)
<br>
Join the [Discord](https://discord.gg/rmf6jQpMU9) for support and more sources!

## Current Repo

| Source Type | Description |          Link |
| ---        |    ----   |         --- |
| Stable  (0.5)    | Stable versions of sources made for Paperback 0.5. (Deprecated)     | [Click me!](https://thenetsky.github.io/netskys-extensions/main/)    |
| Stable (0.6)   | Stable versions of sources made for Paperback 0.6/0.7 (Deprecated)        |  [Click me!](https://thenetsky.github.io/netskys-extensions/0.6/)    |
| Stable (0.6-nsfw)   | Stable versions of NSFW sources made for Paperback 0.6/0.7 (Deprecated)     |  [Click me!](https://thenetsky.github.io/netskys-extensions/0.6-nsfw/)    |
| Stable (0.8)   | Stable versions of sources made for Paperback 0.8       |  [Click me!](https://thenetsky.github.io/netskys-extensions/0.8/)    |
| Development   | Development versions of the sources. (Unstable)        |  [Click me!](https://thenetsky.github.io/netskys-extensions/dev/)    |
